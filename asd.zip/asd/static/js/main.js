$(document).ready(function() {

    var additem = $(".meal");
    var button = $("<button>").text("search").addClass("meal-btn").attr("id", "load-content-button");
    var meal = $("<div>")
    additem.append(meal, button)

    $("#load-content-button").click(function() {        
        axios.post("/meal-api", { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
            .then(function(response) {
                var res = response.data
                console.log(res)
                for (var key in res) {
                    console.log(res[key])
                    var html = "<p>"+res[key]+"</p>"
                    console.log(html)
                    meal.append($("<div>").html(html))
                }
            })
            .catch(function(error) {
                console.log(error);
                $("#loading-container").remove();
            });
    });
});