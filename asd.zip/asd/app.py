from flask import Flask, render_template, jsonify, request
import meal 

app = Flask(__name__)

@app.route('/')
def main():
    return render_template('main.html')

@app.route('/meal-api', methods=['GET', 'POST'])
def meal_api():
    if request.method == 'GET': print('error')
    elif request.method == 'POST' :
        meals = meal.meal()
        result = {}
        result['first'] = str("\n".join(meals[0]))
        # print(result['first'])
        result['second'] = str("\n".join(meals[1]))
        result['thirth'] = str("\n".join(meals[2]))
        return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')